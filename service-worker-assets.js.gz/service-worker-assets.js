self.assetsManifest = {
  "version": "2TXWtWQ5",
  "assets": [
    {
      "hash": "sha256-vHvXdYUYlmEZk97fUurcJV6GB5jPfYCarVGxIWYkbV0=",
      "url": "TableClothLite.styles.css"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-RC8P8iQcUu/cx7osATv0xSw2X8G3utkMtThwigsND5g=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-VTVI/re1ApVcgtRkW/BCIm/PIfVM3iBZEQcVZzuTARo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-abaSp2xCB2qa0FHuc/9VKt39+MybEnIoOItPufNTSr4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-m9D6O5smUPMQWbjax0bH03XYtdI3RD5geOwhizeT+gE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-3+jF/yOfwYyQhLujhQlSrvp3NBll+oEUF7v13pin53A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-2bhET+uXWbAao2aJyUqqscx9PObMTXmpUAkDQOQBGI8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-nIU5FWzn1UKAWh1+g35w3aDIn8pSmnmQV1YWZ+1eb8w=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-C/YKywsVlWaSpZ1PLDeRKkkkM6ki2G2gT9ny+WVuERA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-5Xro3i41QLeYkA4vXMC3sJ/GOerzbXq4CJRFnA+jYNE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-EnvcMggAdstebmtcZrEOhDW5p/e0dFj2ZywJtuMypIw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-htNuF2gbem5vP85zcYVih92CTJrIeZj4ghrN/AHd9VM=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-VHCb/U7GL6QVbx5psaGUdfmCzhTRPWRUuIbJLkEigYo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-w9RAuNcjZZAQYfMpGc5vjpROURS1+Qd/eifqapSq134=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.nv5wbdzqw1.bundle.scp.css"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-kX+9ky61TMxar94Z7+S8myontpvgH4571DVehjxVvM4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-hrddFZ8efNVTQbfpDGaEY8fLQ9Z8DxuyTQ7XZoTgwy4=",
      "url": "_framework/CommunityToolkit.Mvvm.q3c1ofp6kt.wasm"
    },
    {
      "hash": "sha256-yulf19T49qtzKewPIpDYL8YULYAaNllaxVRc5wxAxOU=",
      "url": "_framework/Microsoft.AspNetCore.Components.6p8b5psomz.wasm"
    },
    {
      "hash": "sha256-XJTogJg+nDVH/iWuDIITBJaY6q6m5TqXUpiPgNu2hGI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.wfqyq8qfz8.wasm"
    },
    {
      "hash": "sha256-Fnpdx5PoSwqfPh9GwydL0Goj7jRumxLiPwQa307BhPI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.y2wug6m9bv.wasm"
    },
    {
      "hash": "sha256-tquitL1VnihRL+IDoQsPvX/ysRbYtYozTMqmcWCgS+Q=",
      "url": "_framework/Microsoft.Extensions.Configuration.6ox5i8clg3.wasm"
    },
    {
      "hash": "sha256-fz9asIo72toOZ9cKUQqpnpGkfFowRGMPHuDYGab4zl0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.z7m4i5rnyp.wasm"
    },
    {
      "hash": "sha256-XQykit2HYxnB0emmOc5bra6XuZq3KgCfazi8kFAErDs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jgtmx19396.wasm"
    },
    {
      "hash": "sha256-EMUlZGI57gXUmujDlt6Wibh+QvMwBf8FWhqwJFGQD8k=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.4nnd6ns5h9.wasm"
    },
    {
      "hash": "sha256-wPj/fOeoE7JKOgIYh6OIvl/k3Iw6EPDmmXDjtnQ6rJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g0r86u4i0h.wasm"
    },
    {
      "hash": "sha256-tEtUKTeItXncbYJzaOn0W/BY6wHDdtVCzr0FPuKmN4M=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.o97u05c9gb.wasm"
    },
    {
      "hash": "sha256-u4RUZ6A9cWnQlgCP/S7IxI1Wh8+1iQrhwgBkYE0TEWo=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.lk2ttr0x6l.wasm"
    },
    {
      "hash": "sha256-rrZfQjrMrrbSyNuZ4q8AzD984pAuF9TzvewPRrbA2pY=",
      "url": "_framework/Microsoft.Extensions.Http.6zqn1oe2fi.wasm"
    },
    {
      "hash": "sha256-dkXIjUcXGiBO7YS3U5syQ784UtnjGQHCb2yIeo9JyP0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.2deze1yms2.wasm"
    },
    {
      "hash": "sha256-QhWV6R3UsAbvd90hOpKEo7wmHVsEGWtliqDxgSwvMrw=",
      "url": "_framework/Microsoft.Extensions.Logging.y3zk4eoscr.wasm"
    },
    {
      "hash": "sha256-UIbQSVx6SN1qBPZTZyeZAoTd3ZiY7RvlOEGUMT+0RL0=",
      "url": "_framework/Microsoft.Extensions.Options.gwcojngm5h.wasm"
    },
    {
      "hash": "sha256-+HoDX+e0bGwi8OjZvR5ZpN4OxMMBE8OX4f2wu++wdqE=",
      "url": "_framework/Microsoft.Extensions.Primitives.geznw6vy35.wasm"
    },
    {
      "hash": "sha256-e9L+QmmhESIuNgAKHaeYgdNiRcjGl88sHM7mHhX0280=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.Emojis.Symbols.nth555p4gd.wasm"
    },
    {
      "hash": "sha256-LCvRWo/mmuYZNK6o5PDGFQ0halSG2Zzfr3eYPnFJvlk=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.gne0dxlhum.wasm"
    },
    {
      "hash": "sha256-hbzWuXrlepIqY/y+nQ2ZAFer2/njy1dc+Y4LUaAaL5E=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.p386u0jty9.wasm"
    },
    {
      "hash": "sha256-AkxagDN4XaHOeoUzzdkZHp70lGWQlSofx4OAQ1upark=",
      "url": "_framework/Microsoft.JSInterop.yzbhx3vnl7.wasm"
    },
    {
      "hash": "sha256-J9xsM9+4ygy5M7zb7V8i7py6SXDp3HQ00lbDruRIi2Y=",
      "url": "_framework/System.Collections.Concurrent.d7plxol53k.wasm"
    },
    {
      "hash": "sha256-0rT/VUf60jdmXbg9jpWivJtbtBGZx9zuiNtjB3sQXRU=",
      "url": "_framework/System.Collections.Immutable.2sa1og7wky.wasm"
    },
    {
      "hash": "sha256-mVpFOx8MfKYPsYzZzt3mzVa/yTgc9QJdysTmKRnghL8=",
      "url": "_framework/System.Collections.NonGeneric.5hbaq6dkj0.wasm"
    },
    {
      "hash": "sha256-obtNm23t73/t30sbb7+zumrA66ZelRVbNtHoQ4chkTk=",
      "url": "_framework/System.Collections.zbbk62co2y.wasm"
    },
    {
      "hash": "sha256-os2jGthJCeU5X0qkzYb49CiwYc+7+IoMMAv3Iby8hoM=",
      "url": "_framework/System.ComponentModel.Primitives.6bhs3d9ro6.wasm"
    },
    {
      "hash": "sha256-Dnpwz4DIY3AZo9Xj2KRu26t5vq6kG0rZCj2liQkwPd0=",
      "url": "_framework/System.ComponentModel.TypeConverter.ekfl0yfi5s.wasm"
    },
    {
      "hash": "sha256-NQkKskUXENdTSf2C0+y41sjKi68CHmUqCgPPLNxKyGw=",
      "url": "_framework/System.ComponentModel.h9eo79o86x.wasm"
    },
    {
      "hash": "sha256-9xsTymOJD+9gCAfxZT9IdK/Soyr2sgfBJ8ot2Mvazwg=",
      "url": "_framework/System.Console.7gnluh767y.wasm"
    },
    {
      "hash": "sha256-dFJ4s+0A6SMTU4YGddhjH3h7FTIWNibP19ze5+gfsDQ=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.s6cnl0kd35.wasm"
    },
    {
      "hash": "sha256-M7/+9/ns/JmfNshhdPEogtyU+xqGe+Jhe+bgTCt7pPI=",
      "url": "_framework/System.Drawing.Primitives.xbamzcvn2x.wasm"
    },
    {
      "hash": "sha256-cmtCvFHpnhsv3Pq45BZpEFzMXBDC9DJe7KZrvrC7+xw=",
      "url": "_framework/System.Drawing.y0hpp8feho.wasm"
    },
    {
      "hash": "sha256-H0xX4tICl058T7yZZfc99/oq/5CBPd46yfhY4Z6/9fs=",
      "url": "_framework/System.IO.Compression.7qz5wmlyo7.wasm"
    },
    {
      "hash": "sha256-V5z9/XlJMVOFEDQ+R/mfLxmcykbKzh9+yhFeRdF4kdU=",
      "url": "_framework/System.IO.Pipelines.h68d94scrb.wasm"
    },
    {
      "hash": "sha256-w2dyafvae8of+435YkIaaI/jhG07SjdQuPEibOAMdRU=",
      "url": "_framework/System.Linq.vlvr3jk5rq.wasm"
    },
    {
      "hash": "sha256-SrBVMo6y8K0FW1a07/LPx+E73mNBQDIPA1+IPvft0aI=",
      "url": "_framework/System.Memory.acxyzgdz32.wasm"
    },
    {
      "hash": "sha256-qapAyZaJmbxZtmQcpPj4V+iZMSC/bi3zAEr7AxMBkrY=",
      "url": "_framework/System.Net.Http.dr99hosdkp.wasm"
    },
    {
      "hash": "sha256-ZeNwhIn7WkoYVZst+ETUsP6vnhBj3XKvQJwcdhz+yVM=",
      "url": "_framework/System.Net.Primitives.58k8z28kfs.wasm"
    },
    {
      "hash": "sha256-f12KaRI790QI4todTIDkMZwA9ZmRTTy0vNHRSasEZl8=",
      "url": "_framework/System.ObjectModel.bhl7xtyyyb.wasm"
    },
    {
      "hash": "sha256-SvVPQjjKaXHuv35SlcdcXLzi5DR+CR4VAzScBpzJ14s=",
      "url": "_framework/System.Private.CoreLib.2xpapoh5xs.wasm"
    },
    {
      "hash": "sha256-s1gZZsMf55uh+u9ZIodFCQUGTNMpvFUznQkMPVDrKQc=",
      "url": "_framework/System.Private.Uri.p9v0xq2afe.wasm"
    },
    {
      "hash": "sha256-9bF7Jiaf0z1Z/u2TfTli/wL07QK9Z+WXwYzCeJ24guI=",
      "url": "_framework/System.Private.Xml.1d2kxyah17.wasm"
    },
    {
      "hash": "sha256-r+LQmgoVdHgFKWJvUNAR7HQZAtSw+xvBIQ6siSPsBNM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f4ln4hfftw.wasm"
    },
    {
      "hash": "sha256-ztkPnV51KNK0tfujdjAuaEy35qJ/1wePjK1QS7ZZYv4=",
      "url": "_framework/System.Runtime.a2ijkcsldp.wasm"
    },
    {
      "hash": "sha256-gAQK1aO5MWD0GwIAc812qHpnec5wlHwgnyaZ9RGOUOg=",
      "url": "_framework/System.Text.Encodings.Web.4zpcd8unrt.wasm"
    },
    {
      "hash": "sha256-yvfkdfKbG4ixDHGwZljQGUsDwTo237iljpz44YdYmPI=",
      "url": "_framework/System.Text.Json.u68zob5una.wasm"
    },
    {
      "hash": "sha256-SKkTQL9D0Loskr+NX705/WITcRNb/8VQlQorMrz5S6M=",
      "url": "_framework/System.Text.RegularExpressions.0e9rlv7vxy.wasm"
    },
    {
      "hash": "sha256-WjFhNoqDakPfhmk06Q6kT90meqzgW79kWuCJ7bARXlI=",
      "url": "_framework/System.Xml.ReaderWriter.6wqm56mhp6.wasm"
    },
    {
      "hash": "sha256-FxgsrW9feMSIjvIGwl0Whfc3LwIGtNe61SiAGVHZ044=",
      "url": "_framework/TableClothLite.Shared.98gzvz8h9m.wasm"
    },
    {
      "hash": "sha256-laCxCU64usnvxSuSdQgDn/dfxAaMT01m7H1QpQFQqSY=",
      "url": "_framework/TableClothLite.ji5uwig9wt.wasm"
    },
    {
      "hash": "sha256-kHl9IS0fD3wTBtc7XH41EURHCsmr9Qlo/puOIAW7NxU=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/pcrNUZIFxvVrfML8zazMdEZ+IB0TdSKqJ6mAPvV+w4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-HFADmT26AarHu4tMjFaTPxINmQjBJGtdPN+CKjtNMFE=",
      "url": "_framework/dotnet.native.8bti36lthm.js"
    },
    {
      "hash": "sha256-F3/BArijJUydqmwcdWeW3LYyYHBRSu2+pyy8GL1jTV0=",
      "url": "_framework/dotnet.native.tr0cyonrwt.wasm"
    },
    {
      "hash": "sha256-82FoDmY+LsehdN2u8aSGEutGEKXJHcYaSX/3zptbsCw=",
      "url": "_framework/dotnet.runtime.tsg4gsv2hg.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-wWTOoTYqjE5Kyp+lSG0WJeIJXaD+J3n1OHqifws9gas=",
      "url": "assets/installer.txt"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-6137ORcv2I0QD3yFSFTlha10nbY05fAhgh+4NKdNXwQ=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-MTMjfKgyVIECYmky/sqXeuQhADa081bxf9xQNVD0QTM=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-u/F3yhtHl/7OrMQzmMcgpJjRHP7L+pQV46Abv9Zf7Gk=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-qzzGsmvps4++By+AgvJ7fKclSig/rXV+/tuTSZaJO9w=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-dBY/6wSUpBmYIBqYBzucAkgxE4Z9db2VFPtGOIkyKfo=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-uvqhxzoL84bMDgEAqN9zXskptlslQXmdDPf0RtzNrwM=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-nZ/Qg9VmbTeN5RV/ix2JFeBE6tHvRFsxv1aoGPKIqSY=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-OtBaHKCppSkTX5/zt39QCHgcxIjf916OdtBLOzZ9Hbk=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-adX73XOlkBt3+dUTo5W1PwgkJPVW8jYCvrCW9iT3F4o=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-Cy7OypuiowrXUTrtx3Cs+0uYteNxXTe7kbbkNu624Zo=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-pxYvfpIYKWykWk7yekBNOAboswBij3inSe8amhnFWsc=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-Nlt7zXsu4sdhv3glnrh5cAJzOLJKFg8imceWd28kIZw=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-cldNuE+qZVBobDSIjT7YFv9+qiMJLNic72fLH+TKT3A=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-sM1JIKfZgdih+s8IeORnTZpAh8KHb7zAcfnfcDLmQNo=",
      "url": "manifest.webmanifest"
    }
  ]
};
