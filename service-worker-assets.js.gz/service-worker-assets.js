self.assetsManifest = {
  "version": "ynSDYrqo",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Na6CFBNlQ4ZciMeS87cK2F+oZYWqnb9r0DnvC8t7olM=",
      "url": "404.html"
    },
    {
      "hash": "sha256-qcRVQXdJpbEfGnOMpwrQPm8dszwSxeC+TSfsLGzXgkM=",
      "url": "PWA-ICONS-GUIDE.md"
    },
    {
      "hash": "sha256-7h0RkKAWhTVPK8R3IndGMDxjBFt9vO1atmZUfLx3+Lc=",
      "url": "Pages/Home.razor.js"
    },
    {
      "hash": "sha256-w+atiU9DHs2nCaNNl+SfT3YadJjJdkmHNTLW6/KRlDo=",
      "url": "TableClothLite.styles.css"
    },
    {
      "hash": "sha256-kiD87S/tghFUydyHWNfGo1G3AnugOsqK5Y55LSHS43w=",
      "url": "_framework/AngleSharp.up7648hgwu.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-r5H+rUlGPpjyNTjRl9sPHtsy0fxPqCRow0c5r+XtBk8=",
      "url": "_framework/Markdig.hc946gumly.wasm"
    },
    {
      "hash": "sha256-wVquknLD7l5WWpVzHFQQylf+Qov/WFCQFhMgFh2kR1c=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.dtacdr6vxh.wasm"
    },
    {
      "hash": "sha256-qt+v6LuBCug4Xgxc+3oyi9vVJGwkQ0CLB4r/uEJRalY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.akxznl25k0.wasm"
    },
    {
      "hash": "sha256-88ITmRcx68ghfc1EcdOtH5GxgdAADHmXO2NwCz2+VwM=",
      "url": "_framework/Microsoft.AspNetCore.Components.rm4e4cg6do.wasm"
    },
    {
      "hash": "sha256-FVwG7fRbAmW1Lic76hVRI7KlrLtXgThF1k1glJjbguE=",
      "url": "_framework/Microsoft.Extensions.Configuration.7hcza4a0bh.wasm"
    },
    {
      "hash": "sha256-SUyUxuyBdCImwdyTd50LAg5dAPtW1EAR6CRjvEgCxVk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.p8921wxa9v.wasm"
    },
    {
      "hash": "sha256-i4UmIVmRYt9sXQYxprJFXFivAl11xAcf9azr6KH7EOw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.j66pezmcjo.wasm"
    },
    {
      "hash": "sha256-L0gKlFa7AQsvP007eQ4ALhHpqaBXyYvMICxdgcQvfc8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.fooxts6bq8.wasm"
    },
    {
      "hash": "sha256-Ta3surCTEATmQUY4SQ/wpAIdyxK5fNnI4bm05ePwAsw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.vdgbrs4or0.wasm"
    },
    {
      "hash": "sha256-tEtUKTeItXncbYJzaOn0W/BY6wHDdtVCzr0FPuKmN4M=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.o97u05c9gb.wasm"
    },
    {
      "hash": "sha256-u4RUZ6A9cWnQlgCP/S7IxI1Wh8+1iQrhwgBkYE0TEWo=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.lk2ttr0x6l.wasm"
    },
    {
      "hash": "sha256-sRLhNMcl46Jn6vSRo5GP+0i6/F22MxBKkaQOTok9zR0=",
      "url": "_framework/Microsoft.Extensions.Http.9qwcqulsre.wasm"
    },
    {
      "hash": "sha256-zijb3aQ316u757diaSIUVn1C6cS1OTnapAKj81W+w9w=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.elnj9o91n5.wasm"
    },
    {
      "hash": "sha256-sKOjZ6H5TkO/+qfWsNQ+u++TkQ+Yvcs3Kof4x3XGpkA=",
      "url": "_framework/Microsoft.Extensions.Logging.oyrf5zd3yr.wasm"
    },
    {
      "hash": "sha256-zG93jidCj4vBcVrLdr3CRtyNM05ws3tdBGjyDTdb9jQ=",
      "url": "_framework/Microsoft.Extensions.Options.cye6fgpn51.wasm"
    },
    {
      "hash": "sha256-9sBOSpmqVgdkfoIHyEZ5pl7+xVNmC6ndBL6zcSGBAf8=",
      "url": "_framework/Microsoft.Extensions.Primitives.2t6a8ek1ml.wasm"
    },
    {
      "hash": "sha256-63bzxZLVvNOmTsso6iLrptxGmKBQh2HUIEGtPUrRPeQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.lsljofql11.wasm"
    },
    {
      "hash": "sha256-S4k55jK0rV6BqBBRfQOjGy9TdK3eu0BlNOBQZKTHEeI=",
      "url": "_framework/Microsoft.JSInterop.dyijc12pgi.wasm"
    },
    {
      "hash": "sha256-uxHw3sMSOpv1iAp+dXTWaJmDcy2flsRlh0/q7LyNL/E=",
      "url": "_framework/OpenAI.htygymavmz.wasm"
    },
    {
      "hash": "sha256-/qrTYA4sY3TLfI0xlciDnhqe6szoNn0X4zoI2gDqZag=",
      "url": "_framework/System.ClientModel.6rv1e89mqt.wasm"
    },
    {
      "hash": "sha256-b09QhLFlK4l9SLhwvoJp0Wn91f6L2YfMGYzXWqmaV68=",
      "url": "_framework/System.Collections.Concurrent.vciun8cpf4.wasm"
    },
    {
      "hash": "sha256-Qd4yX9OzA3j3zxqkbe/i/b0ML3paIfdZX7Bh+k+uIio=",
      "url": "_framework/System.Collections.Immutable.r9qje6fm17.wasm"
    },
    {
      "hash": "sha256-U3YB9Z7s8EHNj2TMkgwvQjc+MtMGbpxsZgnms5NUNNo=",
      "url": "_framework/System.Collections.NonGeneric.xrc8rjfup9.wasm"
    },
    {
      "hash": "sha256-1+wj70vsEcfS5dJQmgbVotsxjmXwib+/07lwmJjxxf4=",
      "url": "_framework/System.Collections.Specialized.9wqoxtmbkj.wasm"
    },
    {
      "hash": "sha256-7FJAcEW1/1qKmFev9/339sd41TwBRLWdtQMoqU3y2IE=",
      "url": "_framework/System.Collections.sqx9mh2nyi.wasm"
    },
    {
      "hash": "sha256-DHujPeYswdt0JOBw03JC11hmqQ+Vtb1K9fkbgtDLtTM=",
      "url": "_framework/System.ComponentModel.0n5errmvx8.wasm"
    },
    {
      "hash": "sha256-uF3+ccS0JkFJ35TLnMMLOVGbw1Ot8bRhEsYhha1kpOY=",
      "url": "_framework/System.Console.8gzddztkdh.wasm"
    },
    {
      "hash": "sha256-sD0xVT6N1FAuJBx87xfmCRocDd+28cgxSuJ0/MBfW5Y=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.cp6zpqhf1z.wasm"
    },
    {
      "hash": "sha256-tCvlwGJAx3TJMot5V3EE7CsL75IH2QH821792tEpUhM=",
      "url": "_framework/System.IO.Pipelines.kapd30rafw.wasm"
    },
    {
      "hash": "sha256-ao6c6hgnQG2pqFzU6tfv6pPnqwdnaqQ0TNHlBpbhKt4=",
      "url": "_framework/System.Linq.qjlmffpnbq.wasm"
    },
    {
      "hash": "sha256-LLRUs90DpXCFrIX6cF8tZ5lZ1lI7IGlrszGI5/IQTfM=",
      "url": "_framework/System.Memory.Data.8za9wb4dav.wasm"
    },
    {
      "hash": "sha256-RczyBN7TD4TKH39/0U1A13Rl1Z+aaf5i4HpDblVjTVQ=",
      "url": "_framework/System.Memory.zq7ulzpqma.wasm"
    },
    {
      "hash": "sha256-qZKIAog76gQDkdPtyJnUWNqLp6WpMfeB8NdSTOvIs2M=",
      "url": "_framework/System.Net.Http.1mpsetcoa1.wasm"
    },
    {
      "hash": "sha256-8HRlqxUZsSLYp9Ree2yyfE+Lc9c0odsxGohcjgpx1+Y=",
      "url": "_framework/System.Net.Http.Json.g8alg5ul1v.wasm"
    },
    {
      "hash": "sha256-NGn7b1IBWc80ziVddwcH82qm3NqfRTARCJCHXgtNguY=",
      "url": "_framework/System.Net.Primitives.w133zt61bs.wasm"
    },
    {
      "hash": "sha256-yGFKGBgwstGUQ3ymaznQpYAOplAE13ivhnzbIwZkuYw=",
      "url": "_framework/System.Net.Requests.g650o30y2a.wasm"
    },
    {
      "hash": "sha256-b1NVv/vZntzl9+zMVJMWeRUZpBdaiVmDnvKQMzaob+k=",
      "url": "_framework/System.Net.ServicePoint.py7heb5pre.wasm"
    },
    {
      "hash": "sha256-P8y+ohJp3X193KHgrKdzErDm5+yNSoDLR4yw0MWBLec=",
      "url": "_framework/System.Net.WebHeaderCollection.vsnrrgugpb.wasm"
    },
    {
      "hash": "sha256-+ncBBAE9UTavxHR0pFO1N9dYpBWQ81UycZsW6ahrGV0=",
      "url": "_framework/System.Net.WebSockets.25pbwdsgq1.wasm"
    },
    {
      "hash": "sha256-DriS03NETwmYr9Y7KTDkxLawsKjqURyYQP0VttEAuL8=",
      "url": "_framework/System.Net.WebSockets.Client.yofi8okmp1.wasm"
    },
    {
      "hash": "sha256-hgCHcqD7Xr20HZVY2306rT5M10WSlpcUrFlUHV6CRZE=",
      "url": "_framework/System.ObjectModel.y2l7llzfxd.wasm"
    },
    {
      "hash": "sha256-/rVwWGB+MaYjjyxXd7MbMGDwkKt6qFrPacbrVqEsgXM=",
      "url": "_framework/System.Private.CoreLib.6m62o0dlh2.wasm"
    },
    {
      "hash": "sha256-gwBBpTdB4mAg6LTbzjRrPhtGHigW8Ikn9SoZswLFZ3Q=",
      "url": "_framework/System.Private.Uri.jgbiarmsqw.wasm"
    },
    {
      "hash": "sha256-TLt3UShiXKtf17l1DqIzyL7c094ouzpl6zpNct2YZdk=",
      "url": "_framework/System.Private.Xml.k2nymfe3ma.wasm"
    },
    {
      "hash": "sha256-aOdXwUnAPFNtDQrAvvmH+8qUi7COfljvTuneiaRT3xg=",
      "url": "_framework/System.Runtime.4tti86yany.wasm"
    },
    {
      "hash": "sha256-+/uNVQu/ULMwSnn1LviIWo1xHAV+nuORcVn7tHX52Sc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.7p7wh7ew2r.wasm"
    },
    {
      "hash": "sha256-xSQWXZYLJTmae3uZowZZOmJqyZemUc1QXGLzAXfhbx4=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.3yfmpmhkai.wasm"
    },
    {
      "hash": "sha256-LfM6BypmGux3PI4QlIFNgVImNiJP2cT2bRxIdmr+NEc=",
      "url": "_framework/System.Runtime.InteropServices.t4gipi9sfm.wasm"
    },
    {
      "hash": "sha256-zGSRZNUVHasjEJUFiUiRRt3Y8PIGW96ZbrVWclB0snk=",
      "url": "_framework/System.Security.Cryptography.4yom5q7sg1.wasm"
    },
    {
      "hash": "sha256-2Q2tDhnseh3PCPfnx5lLqemOAGuNNY00LBQzGDXycxc=",
      "url": "_framework/System.Text.Encoding.CodePages.rzicnonnz2.wasm"
    },
    {
      "hash": "sha256-MPM0NHK0FzpVpCdBDJQOXU4mKhQkpXdsk8gF06iNP+Q=",
      "url": "_framework/System.Text.Encoding.Extensions.oqztlhw6l1.wasm"
    },
    {
      "hash": "sha256-nowVPzdhrYNVwBj7BFC6KceUhojJ5Gz2vZGxT0qFoSA=",
      "url": "_framework/System.Text.Encodings.Web.e8bnsydrha.wasm"
    },
    {
      "hash": "sha256-Av5sfjNUL7j5I/2Z5n75Vam3PihsVEcTl0kBjTQca+A=",
      "url": "_framework/System.Text.Json.ukhwx0uhkp.wasm"
    },
    {
      "hash": "sha256-7LlWgSvn2kkuR0hPCGUDzcBlKl41vMvqRBNrzAK6xcU=",
      "url": "_framework/System.Text.RegularExpressions.8dx83bn43i.wasm"
    },
    {
      "hash": "sha256-8P2hHDMhWmFasTjydp596prdpBK7XM8QOkUCY/ZBx+k=",
      "url": "_framework/System.Threading.82acoiyymq.wasm"
    },
    {
      "hash": "sha256-nzqHKM0RCFuQaIYR5w38e0c1uPmHhXMxrKWl+wkV6Nc=",
      "url": "_framework/System.Threading.Thread.5b1jo4d7mj.wasm"
    },
    {
      "hash": "sha256-heJjIS0TxXlTOzoQF5/OcGGEsa8zaQLoOJWyssZdj1U=",
      "url": "_framework/System.Web.HttpUtility.h1htfqt019.wasm"
    },
    {
      "hash": "sha256-o/aGLZlaugH+0+JJg2HH0YxQ0ZrgpS4EGtufa8qkGOs=",
      "url": "_framework/System.Xml.ReaderWriter.plpjx8ae2q.wasm"
    },
    {
      "hash": "sha256-ZRjouD6b2q/JaR3QCjsPn8UTpulzBdmSQ1+iZGUs90g=",
      "url": "_framework/TableClothLite.Shared.zmumnn7ctl.wasm"
    },
    {
      "hash": "sha256-5xLOJbf5qi3R1+VtP9PcWIvTBj/r93SnFfrAzVPGKi4=",
      "url": "_framework/TableClothLite.x6edsaqjm9.wasm"
    },
    {
      "hash": "sha256-eSAk1kSyVar0R51SRX2yn0kZnPxt2gOt+rhgL70N6yg=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-RtuwNrUOdAJ5A4aS4ZmceO4ySriaYqTdC7X++6yd9lM=",
      "url": "_framework/dotnet.native.21mns4qp4i.wasm"
    },
    {
      "hash": "sha256-oS7IRiQoVt9ThQ7Y2UM3XoeY0JqPD02cg9IvRdufn2w=",
      "url": "_framework/dotnet.native.9ih887ebfz.js"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-2BU7e7TWpZVmL3bn7kCsz4QHD/wAz60iEC6gIsuH38A=",
      "url": "assets/installer.txt"
    },
    {
      "hash": "sha256-xtMi48nT6KV3KCcL3PoPxN/bO9C6f9f6riUWgSkLUoI=",
      "url": "browserconfig.xml"
    },
    {
      "hash": "sha256-gH3MO/y9F6il1mDGKQ5aNPIadteGoE/tPqfOsZ2r9Ko=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-6137ORcv2I0QD3yFSFTlha10nbY05fAhgh+4NKdNXwQ=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-MTMjfKgyVIECYmky/sqXeuQhADa081bxf9xQNVD0QTM=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-u/F3yhtHl/7OrMQzmMcgpJjRHP7L+pQV46Abv9Zf7Gk=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0M6eI0QGORDNGy99btHvAb6ApbJX1pqrrRsENSnsAQY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-aIoDGefaR2k2vcFFxQeNk/kiKpZmicu0KgS8nnXSlHc=",
      "url": "js/app.js"
    },
    {
      "hash": "sha256-M3onquopaB/1woJqHcVA/rQNGj0qc4ZUnTJsHP7IZRk=",
      "url": "js/theme.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-dBY/6wSUpBmYIBqYBzucAkgxE4Z9db2VFPtGOIkyKfo=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-uvqhxzoL84bMDgEAqN9zXskptlslQXmdDPf0RtzNrwM=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-nZ/Qg9VmbTeN5RV/ix2JFeBE6tHvRFsxv1aoGPKIqSY=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-OtBaHKCppSkTX5/zt39QCHgcxIjf916OdtBLOzZ9Hbk=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-adX73XOlkBt3+dUTo5W1PwgkJPVW8jYCvrCW9iT3F4o=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-Cy7OypuiowrXUTrtx3Cs+0uYteNxXTe7kbbkNu624Zo=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-pxYvfpIYKWykWk7yekBNOAboswBij3inSe8amhnFWsc=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-Nlt7zXsu4sdhv3glnrh5cAJzOLJKFg8imceWd28kIZw=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-cldNuE+qZVBobDSIjT7YFv9+qiMJLNic72fLH+TKT3A=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-af5O1f1u1Me+0xEwTCr9UIvW8QxpGDcHK28Ej30nZ2c=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-pBTYfNQ4p/wNjPm56j8Ufz0hDrLyePHDqLsfj5m6dBs=",
      "url": "offline.html"
    }
  ]
};
